#!/bin/bash

#This shor script is example for file content comparison
#Used in SSC DT project for feature parity comparison

if [ -z "$1" ]; then
			  echo usage: comp3.sh "<DT_Parity_FILE> <new_FEATURES_file>"
			  echo Please check example files for content
			  echo "comp3.sh DT_activated_features.txt 20Q2.2EC2.csv"
			  echo ""
              exit
          fi 
cat $2 | awk 'BEGIN {FS=";"}{print $2}'| grep -i faj > new_FAJ.txt

readarray file_old < $1
readarray file_new < new_FAJ.txt
number=${#file_new[@]}
number2=${#file_old[@]}
((number--))
((number2--))

for ((b=0;b<=$number;b++))
	do 
		found=new
			for ((c=0;c<=$number2;c++))
			do
				if [ "${file_new[${b}]}" = "${file_old[$c]}" ]; then
					found=no_new
					echo 'Found in Parity' ${file_old[${c}]}  >> Features_parity_result.log
					echo ${file_old[${c}]}  >> parity_RAW.log
				fi
			done
		if [ ${found} = new ]; then
			echo 'FAJ not in Parity ' ${file_new[${b}]}  >> Features_NOT_IN_parity_result.log
		fi
		echo "Ongoing activity...."${number} "-"${b}
	done
echo "Comparation completed doing final CSV" 
readarray final < parity_RAW.log
number3=${#final[@]}
((number3--))
for ((c=0;c<=$number3;c++))
	do
	echo "Final progress..."${number3}"/"${c}
	grep "${final[$c]}" 20Q2.2EC2.csv > Features_Parity_descr.CSV
	
done

